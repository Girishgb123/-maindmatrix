package com.example.vijay.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary          = SoilBrown40,
    onPrimary        = Color(0xFFFFF8F0),
    primaryContainer = Color(0xFFFFDDB3),
    onPrimaryContainer = DarkBrown,
    secondary        = LeafGreen40,
    onSecondary      = Color(0xFFFFF8F0),
    secondaryContainer = LeafGreen80,
    onSecondaryContainer = DarkBrown,
    tertiary         = WarmAmber40,
    onTertiary       = Color(0xFFFFF8F0),
    background       = Color(0xFFFFF8F0),
    onBackground     = DarkBrown,
    surface          = Color(0xFFFFF3E0),
    onSurface        = DarkBrown,
    surfaceVariant   = Color(0xFFEDD8C0),
    onSurfaceVariant = Color(0xFF5D4037),
    outline          = Color(0xFFA1887F)
)

private val DarkColorScheme = darkColorScheme(
    primary    = SoilBrown80,
    onPrimary  = DarkBrown,
    secondary  = LeafGreen80,
    tertiary   = WarmAmber80
)

@Composable
fun GramaVasathiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
