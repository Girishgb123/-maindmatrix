package com.example.vijay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.vijay.data.FarmStayEntity
import com.example.vijay.viewmodel.GramaVasathiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverScreen(viewModel: GramaVasathiViewModel, navController: NavController) {
    val farmStays by viewModel.allFarmStays.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedActivity by remember { mutableStateOf("All") }

    val allActivities = listOf("All", "Cow Milking", "Field Plowing", "Local Cooking",
        "Bird Watching", "Coffee Picking", "Fishing", "Nature Walk", "Yoga at Sunrise",
        "Paddy Planting", "Bullock Cart Ride", "Cooking Class", "Forest Trek")

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        Text("🌾 Grama-Vasathi", fontWeight = FontWeight.Bold)
                        Text(
                            "Rural Home-Stay Accelerator",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { navController.navigate("add_stay") },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Farm Stay")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by village, host or district...") },
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Activity Filter Chips — FR: filter by activity
            Text("Filter by Activity", style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(allActivities) { activity ->
                    FilterChip(
                        selected = selectedActivity == activity,
                        onClick = { selectedActivity = activity },
                        label = { Text(activity) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            val filtered = farmStays.filter { stay ->
                val matchesSearch = stay.name.contains(searchQuery, true) ||
                    stay.village.contains(searchQuery, true) ||
                    stay.hostName.contains(searchQuery, true) ||
                    stay.district.contains(searchQuery, true)
                val matchesActivity = selectedActivity == "All" ||
                    stay.activities.contains(selectedActivity, true)
                matchesSearch && matchesActivity
            }

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🌱", style = MaterialTheme.typography.displayMedium)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No farm stays found.", color = MaterialTheme.colorScheme.outline)
                        Text("Try a different filter or add a new stay.", 
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(1),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filtered) { stay ->
                        FarmStayCard(stay = stay, onClick = {
                            navController.navigate("farmstay_detail/${stay.id}")
                        })
                    }
                }
            }
        }
    }
}

@Composable
fun FarmStayCard(stay: FarmStayEntity, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column {
            // Hero image area with gradient
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.secondary
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("🌾", style = MaterialTheme.typography.displayLarge)

                // Readiness score badge
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp),
                    color = when {
                        stay.hostReadinessScore >= 80 -> Color(0xFF4CAF50)
                        stay.hostReadinessScore >= 50 -> Color(0xFFFF9800)
                        else -> Color(0xFFF44336)
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "✓ ${stay.hostReadinessScore}% Ready",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Availability badge
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp),
                    color = if (stay.isAvailable) MaterialTheme.colorScheme.secondaryContainer
                            else MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        if (stay.isAvailable) "Available" else "Booked",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (stay.isAvailable) MaterialTheme.colorScheme.onSecondaryContainer
                                else MaterialTheme.colorScheme.onErrorContainer,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column(modifier = Modifier.padding(14.dp)) {
                Text(stay.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
                Text("by ${stay.hostName} · ${stay.village}, ${stay.district}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)

                Spacer(modifier = Modifier.height(8.dp))

                // Activity chips (first 3)
                val activityList = stay.activities.split(",").map { it.trim() }.take(3)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    activityList.forEach { act ->
                        SuggestionChip(
                            onClick = {},
                            label = { Text(act, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                    if (stay.activities.split(",").size > 3) {
                        SuggestionChip(
                            onClick = {},
                            label = { Text("+${stay.activities.split(",").size - 3} more",
                                style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "₹${stay.pricePerNight}/night",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (stay.reviewCount > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, null,
                                tint = Color(0xFFFFD700), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "${"%.1f".format(stay.rating)} (${stay.reviewCount})",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Text(
                        "Max ${stay.maxGuests} guests",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        }
    }
}
