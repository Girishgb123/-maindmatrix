package com.example.vijay.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [FarmStayEntity::class, ChecklistItemEntity::class, BookingEntity::class, ReviewEntity::class],
    version = 1,
    exportSchema = false
)
abstract class GramaVasathiDatabase : RoomDatabase() {
    abstract fun dao(): GramaVasathiDao

    companion object {
        @Volatile
        private var INSTANCE: GramaVasathiDatabase? = null

        fun getDatabase(context: Context): GramaVasathiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GramaVasathiDatabase::class.java,
                    "grama_vasathi_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed sample data on first launch
                            INSTANCE?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    seedSampleData(database.dao())
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedSampleData(dao: GramaVasathiDao) {
            // Sample Farm Stay 1
            val id1 = dao.insertFarmStay(
                FarmStayEntity(
                    name = "Gowda's Millet Farm",
                    hostName = "Ramappa Gowda",
                    village = "Konanur",
                    district = "Hassan",
                    description = "Experience the authentic rural life in the heart of Karnataka's farming belt. Wake up to the smell of fresh earth and freshly brewed filter coffee.",
                    activities = "Cow Milking,Field Plowing,Local Cooking,Bird Watching,Bullock Cart Ride",
                    pricePerNight = 1200,
                    maxGuests = 4,
                    hostReadinessScore = 80,
                    isAvailable = true
                )
            )
            // Seed checklist for farm stay 1
            seedChecklist(dao, id1)

            // Sample Farm Stay 2
            val id2 = dao.insertFarmStay(
                FarmStayEntity(
                    name = "Lakshmi's Arecanut Estate",
                    hostName = "Lakshmi Bhat",
                    village = "Mudigere",
                    district = "Chikkamagaluru",
                    description = "Nestled in the Malnad region, this estate offers lush greenery, coffee plantations and the famous Matti-Vasane (scent of the soil) experience.",
                    activities = "Coffee Picking,Local Cooking,Nature Walk,Yoga at Sunrise,Cooking Class",
                    pricePerNight = 1800,
                    maxGuests = 6,
                    hostReadinessScore = 90,
                    isAvailable = true
                )
            )
            seedChecklist(dao, id2)

            // Sample Farm Stay 3
            val id3 = dao.insertFarmStay(
                FarmStayEntity(
                    name = "Narayana's Paddy Fields",
                    hostName = "Narayana Hegde",
                    village = "Sirsi",
                    district = "Uttara Kannada",
                    description = "Step into the paddy fields and learn the age-old art of rice cultivation. Enjoy home-cooked Saraswat cuisine by the riverside.",
                    activities = "Paddy Planting,Fishing,Local Cooking,Forest Trek,Village Market Visit",
                    pricePerNight = 900,
                    maxGuests = 3,
                    hostReadinessScore = 60,
                    isAvailable = true
                )
            )
            seedChecklist(dao, id3)

            // Seed a sample review
            dao.insertReview(ReviewEntity(
                farmStayId = id1,
                guestName = "Priya from Bangalore",
                rating = 5,
                comment = "The most grounding experience of my life. Ramappa uncle's hospitality was world-class. The sunrise view over the millet fields was priceless!"
            ))
            dao.insertReview(ReviewEntity(
                farmStayId = id2,
                guestName = "Karthik Sharma",
                rating = 5,
                comment = "Woke up at 5 AM to watch them pick coffee. The smell alone was worth the whole trip. Lakshmi amma's cooking is absolutely divine!"
            ))
        }

        private suspend fun seedChecklist(dao: GramaVasathiDao, farmStayId: Long) {
            val items = listOf(
                // Hygiene — 5 items × 10pts = 50 pts
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Clean bed sheets provided", category = "Hygiene", pointsValue = 10),
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Western-style toilet available", category = "Hygiene", pointsValue = 10),
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Safe drinking water (filter/boiled)", category = "Hygiene", pointsValue = 10),
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Regular pest control done", category = "Hygiene", pointsValue = 10),
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Soap and towels provided", category = "Hygiene", pointsValue = 10),
                // Safety — 3 items × 10pts = 30 pts
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "First aid kit present", category = "Safety", pointsValue = 10),
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Emergency contact numbers posted", category = "Safety", pointsValue = 10),
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Proper locks on guest room door", category = "Safety", pointsValue = 10),
                // Comfort — 2 items × 10pts = 20 pts
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Mosquito nets or repellent provided", category = "Comfort", pointsValue = 10),
                ChecklistItemEntity(farmStayId = farmStayId, itemName = "Menu / food preference discussed with guest", category = "Comfort", pointsValue = 10)
            )
            items.forEach { dao.insertChecklistItem(it) }
        }
    }
}
