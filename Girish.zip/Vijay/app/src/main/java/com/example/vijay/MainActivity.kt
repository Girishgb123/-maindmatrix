package com.example.vijay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.vijay.ui.screens.*
import com.example.vijay.ui.theme.GramaVasathiTheme
import com.example.vijay.viewmodel.GramaVasathiViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GramaVasathiTheme {
                MainApp()
            }
        }
    }
}

sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    object Discover  : Screen("discover",  "Discover",  Icons.Default.Home)
    object Bookings  : Screen("bookings",  "Bookings",  Icons.Default.DateRange)
    object HostTrain : Screen("host_train","Host",       Icons.Default.Star)
    object Guide     : Screen("guide",     "Guide",     Icons.Default.Info)
    object AddStay   : Screen("add_stay",  "Add",       Icons.Default.Add)
}

@Composable
fun MainApp() {
    val navController = rememberNavController()
    val viewModel: GramaVasathiViewModel = viewModel()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val bottomItems = listOf(Screen.Discover, Screen.Bookings, Screen.HostTrain, Screen.Guide)

    Scaffold(
        bottomBar = {
            NavigationBar(tonalElevation = 8.dp) {
                bottomItems.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = null) },
                        label = { Text(screen.label) },
                        selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Discover.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Discover.route)  { DiscoverScreen(viewModel, navController) }
            composable(Screen.Bookings.route)  { BookingsScreen(viewModel) }
            composable(Screen.HostTrain.route) { HostTrainingScreen(viewModel) }
            composable(Screen.Guide.route)     { CulturalGuideScreen() }
            composable("add_stay")             { AddFarmStayScreen(viewModel, navController) }
            composable(
                route = "farmstay_detail/{farmStayId}",
                arguments = listOf(navArgument("farmStayId") { type = NavType.LongType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getLong("farmStayId") ?: 0L
                FarmStayDetailScreen(farmStayId = id, viewModel = viewModel, navController = navController)
            }
            composable(
                route = "book_stay/{farmStayId}",
                arguments = listOf(navArgument("farmStayId") { type = NavType.LongType })
            ) { backStackEntry ->
                val id = backStackEntry.arguments?.getLong("farmStayId") ?: 0L
                BookStayScreen(farmStayId = id, viewModel = viewModel, navController = navController)
            }
        }
    }
}
