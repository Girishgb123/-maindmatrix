package com.example.vijay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class GuideSection(val emoji: String, val title: String, val items: List<String>)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CulturalGuideScreen() {
    val sections = listOf(
        GuideSection(
            emoji = "🙏",
            title = "How to Greet Locals",
            items = listOf(
                "Say 'Namaskara' (ನಮಸ್ಕಾರ) with folded hands — it means deep respect",
                "Address elders as 'Avare' (sir/madam) — it shows immense respect",
                "A simple smile and 'Hoge bandiri?' (ಹೇಗೆ ಬಂದಿರಿ? — How did you come?) breaks the ice",
                "Don't be surprised by direct questions about your family — it's warmth, not nosiness!",
                "Accept any food or tea offered — refusing can seem rude in village culture"
            )
        ),
        GuideSection(
            emoji = "👗",
            title = "What to Wear",
            items = listOf(
                "Prefer cotton clothes — villages can be dusty, muddy and warm during the day",
                "Wear full-length pants or salwar for visiting farms and forests",
                "Avoid revealing clothing, especially when entering homes or temples",
                "Carry a light shawl or dupatta — useful in mornings and for temple visits",
                "Closed-toe sandals or sports shoes are better than flip-flops on farm trails",
                "Remove your footwear before entering any home — always!"
            )
        ),
        GuideSection(
            emoji = "🌾",
            title = "Farm Etiquette",
            items = listOf(
                "Ask before touching crops or animals — always seek permission",
                "Do not pluck fruits, flowers or vegetables without the host's consent",
                "Walk on the edges of fields — never through standing crops",
                "Cows and bulls may be unfamiliar with strangers — approach slowly and calmly",
                "Appreciate the work — a simple 'Thumba chennagide' (so beautiful) goes a long way"
            )
        ),
        GuideSection(
            emoji = "🍽️",
            title = "Food & Dining",
            items = listOf(
                "Meals are often served on banana leaves or traditional steel plates",
                "Eating with your right hand is customary and considered more respectful",
                "It's polite to say 'Thumba chenda aagittu!' (Delicious!) after the meal",
                "Inform your host about dietary restrictions in advance — they'll accommodate happily",
                "Village cooking uses firewood/chulha — food tastes different and wonderful!"
            )
        ),
        GuideSection(
            emoji = "📸",
            title = "Photography Tips",
            items = listOf(
                "Always ask before photographing people, especially women and children",
                "Sunrise over paddy fields is magical — wake up at 5:30 AM for the best light",
                "Festival and puja rituals can be watched but photograph respectfully and quietly",
                "Share the photos with your host on WhatsApp — they genuinely love it!"
            )
        ),
        GuideSection(
            emoji = "♻️",
            title = "Responsible Tourism",
            items = listOf(
                "Carry a reusable bag and water bottle — plastic is a major rural problem",
                "Do not litter on trails, farms, or near water bodies",
                "Buy local produce directly from farmers when leaving",
                "Leave a genuine review — it helps the host attract more guests",
                "Share the experience with friends — you're supporting livelihoods!"
            )
        )
    )

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        Text("📖 Cultural Guide", fontWeight = FontWeight.Bold)
                        Text("City Guest's Rural Handbook",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("🌱 Matti-Vasane Experience",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Matti-Vasane (ಮಣ್ಣಿನ ವಾಸನೆ) literally means 'scent of the soil'. It describes the earthy fragrance after the first rains touch dry earth — the very essence of the rural experience you are about to discover. Read this guide to make the most of it.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            items(sections) { section ->
                GuideSectionCard(section = section)
            }
        }
    }
}

@Composable
fun GuideSectionCard(section: GuideSection) {
    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(section.emoji, style = MaterialTheme.typography.headlineSmall)
                Spacer(modifier = Modifier.width(10.dp))
                Text(section.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(10.dp))

            section.items.forEach { tip ->
                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text("•",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(end = 8.dp, top = 2.dp))
                    Text(tip,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
