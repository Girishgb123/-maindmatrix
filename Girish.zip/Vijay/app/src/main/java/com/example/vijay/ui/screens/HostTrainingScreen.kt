package com.example.vijay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vijay.data.FarmStayEntity
import com.example.vijay.viewmodel.GramaVasathiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HostTrainingScreen(viewModel: GramaVasathiViewModel) {
    val farmStays by viewModel.allFarmStays.collectAsState()
    var selectedFarmStayId by remember { mutableLongStateOf(-1L) }
    var expandedDropdown by remember { mutableStateOf(false) }

    val selectedFarmStay = farmStays.find { it.id == selectedFarmStayId }
    val checklist by (
        if (selectedFarmStayId > 0) viewModel.getChecklist(selectedFarmStayId)
        else kotlinx.coroutines.flow.flowOf(emptyList())
    ).collectAsState(initial = emptyList())

    // Group checklist by category for stepper display
    val grouped = checklist.groupBy { it.category }
    val categories = grouped.keys.toList()
    var currentStep by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = {
                    Column {
                        Text("🏡 Host Training", fontWeight = FontWeight.Bold)
                        Text("Guest Readiness School",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // Farm Stay selector
            ExposedDropdownMenuBox(
                expanded = expandedDropdown,
                onExpandedChange = { expandedDropdown = !expandedDropdown }
            ) {
                OutlinedTextField(
                    value = selectedFarmStay?.name ?: "Select your farm stay...",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Farm Stay") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                ExposedDropdownMenu(
                    expanded = expandedDropdown,
                    onDismissRequest = { expandedDropdown = false }
                ) {
                    farmStays.forEach { stay ->
                        DropdownMenuItem(
                            text = { Text(stay.name) },
                            onClick = {
                                selectedFarmStayId = stay.id
                                expandedDropdown = false
                                currentStep = 0
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (selectedFarmStay == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🏡", style = MaterialTheme.typography.displayLarge)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Select a farm stay to start training",
                            color = MaterialTheme.colorScheme.outline)
                        Text("We'll guide you step by step through the Guest Readiness checklist",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(horizontal = 32.dp))
                    }
                }
            } else {
                // Readiness Score
                ReadinessScoreCard(score = selectedFarmStay.hostReadinessScore)

                Spacer(modifier = Modifier.height(16.dp))

                // Stepper navigation
                if (categories.isNotEmpty()) {
                    StepperBar(
                        steps = categories,
                        currentStep = currentStep,
                        onStepClick = { currentStep = it }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val currentCategory = categories.getOrNull(currentStep) ?: return@Column
                    val currentItems = grouped[currentCategory] ?: emptyList()

                    Text(currentCategory,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold)

                    val categoryDesc = when(currentCategory) {
                        "Hygiene" -> "Basic hygiene ensures your guests feel safe and comfortable. This is the most important category."
                        "Safety" -> "Safety measures build trust with guests from the city who may not be familiar with rural settings."
                        "Comfort" -> "Small comfort touches create memorable experiences and earn better reviews!"
                        else -> "Complete all items in this section to improve your readiness score."
                    }
                    Text(categoryDesc,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(bottom = 100.dp)
                    ) {
                        items(currentItems) { item ->
                            ChecklistItemCard(
                                itemName = item.itemName,
                                isCompleted = item.isCompleted,
                                points = item.pointsValue,
                                onToggle = { viewModel.toggleChecklistItem(item) }
                            )
                        }

                        // Navigation buttons
                        item {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                if (currentStep > 0) {
                                    OutlinedButton(
                                        onClick = { currentStep-- },
                                        modifier = Modifier.weight(1f).height(50.dp),
                                        shape = RoundedCornerShape(12.dp)
                                    ) { Text("← Previous") }
                                }
                                if (currentStep < categories.size - 1) {
                                    Button(
                                        onClick = { currentStep++ },
                                        modifier = Modifier.weight(1f).height(50.dp),
                                        shape = RoundedCornerShape(12.dp)
                                    ) { Text("Next →") }
                                } else {
                                    Button(
                                        onClick = {},
                                        modifier = Modifier.weight(1f).height(50.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF4CAF50)
                                        )
                                    ) { Text("✓ All Done!") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReadinessScoreCard(score: Int) {
    val color = when {
        score >= 80 -> Color(0xFF4CAF50)
        score >= 50 -> Color(0xFFFF9800)
        else -> Color(0xFFF44336)
    }
    val label = when {
        score >= 80 -> "Guest Ready! 🎉"
        score >= 50 -> "Almost Ready"
        else -> "Needs Attention"
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
        border = androidx.compose.foundation.BorderStroke(2.dp, color)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Circular progress indicator
            Box(
                modifier = Modifier.size(64.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    progress = score / 100f,
                    modifier = Modifier.fillMaxSize(),
                    color = color,
                    strokeWidth = 6.dp,
                    trackColor = color.copy(alpha = 0.15f)
                )
                Text("$score%",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = color)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text("Host Readiness Score",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
                Text(label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = color,
                    fontWeight = FontWeight.SemiBold)
                Text("Complete checklist items to improve your score",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun StepperBar(steps: List<String>, currentStep: Int, onStepClick: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, step ->
            // Step circle
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(
                        if (index <= currentStep) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "${index + 1}",
                    color = if (index <= currentStep) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            if (index < steps.size - 1) {
                Divider(
                    modifier = Modifier.weight(1f),
                    color = if (index < currentStep) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant,
                    thickness = 2.dp
                )
            }
        }
    }
    // Step labels
    Row(modifier = Modifier.fillMaxWidth()) {
        steps.forEachIndexed { index, step ->
            Text(
                step,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.labelSmall,
                color = if (index == currentStep) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (index == currentStep) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
fun ChecklistItemCard(
    itemName: String,
    isCompleted: Boolean,
    points: Int,
    onToggle: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted)
                Color(0xFF4CAF50).copy(alpha = 0.1f)
            else MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isCompleted) Color(0xFF4CAF50) else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onToggle, modifier = Modifier.size(32.dp)) {
                Icon(
                    if (isCompleted) Icons.Default.CheckCircle else Icons.Outlined.Circle,
                    contentDescription = null,
                    tint = if (isCompleted) Color(0xFF4CAF50) else MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                itemName,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
                color = if (isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurface
            )
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Text(
                    "+$points",
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
