package com.example.vijay.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GramaVasathiDao {

    // ── FarmStay ──────────────────────────────────────────────────────────────
    @Query("SELECT * FROM farmstays ORDER BY hostReadinessScore DESC")
    fun getAllFarmStays(): Flow<List<FarmStayEntity>>

    @Query("SELECT * FROM farmstays WHERE id = :id LIMIT 1")
    suspend fun getFarmStayById(id: Long): FarmStayEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFarmStay(farmStay: FarmStayEntity): Long

    @Update
    suspend fun updateFarmStay(farmStay: FarmStayEntity)

    @Query("SELECT * FROM farmstays WHERE activities LIKE '%' || :activity || '%'")
    fun getFarmStaysByActivity(activity: String): Flow<List<FarmStayEntity>>

    // ── Checklist ─────────────────────────────────────────────────────────────
    @Query("SELECT * FROM checklist_items WHERE farmStayId = :farmStayId")
    fun getChecklistForFarmStay(farmStayId: Long): Flow<List<ChecklistItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChecklistItem(item: ChecklistItemEntity)

    @Update
    suspend fun updateChecklistItem(item: ChecklistItemEntity)

    @Query("SELECT * FROM checklist_items WHERE farmStayId = :farmStayId AND isCompleted = 1")
    suspend fun getCompletedChecklistItems(farmStayId: Long): List<ChecklistItemEntity>

    @Query("SELECT * FROM checklist_items WHERE farmStayId = :farmStayId")
    suspend fun getAllChecklistItems(farmStayId: Long): List<ChecklistItemEntity>

    // ── Bookings ──────────────────────────────────────────────────────────────
    @Query("SELECT * FROM bookings ORDER BY bookedAt DESC")
    fun getAllBookings(): Flow<List<BookingEntity>>

    @Insert
    suspend fun insertBooking(booking: BookingEntity): Long

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Query("SELECT * FROM bookings WHERE farmStayId = :farmStayId ORDER BY checkInDate ASC")
    fun getBookingsForFarmStay(farmStayId: Long): Flow<List<BookingEntity>>

    // ── Reviews ───────────────────────────────────────────────────────────────
    @Query("SELECT * FROM reviews WHERE farmStayId = :farmStayId ORDER BY timestamp DESC")
    fun getReviewsForFarmStay(farmStayId: Long): Flow<List<ReviewEntity>>

    @Insert
    suspend fun insertReview(review: ReviewEntity)

    @Query("SELECT AVG(rating) FROM reviews WHERE farmStayId = :farmStayId")
    suspend fun getAverageRating(farmStayId: Long): Float?

    @Query("SELECT COUNT(*) FROM reviews WHERE farmStayId = :farmStayId")
    suspend fun getReviewCount(farmStayId: Long): Int
}
