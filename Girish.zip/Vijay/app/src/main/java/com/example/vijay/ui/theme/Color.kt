package com.example.vijay.ui.theme

import androidx.compose.ui.graphics.Color

// Warm earthy palette for Grama-Vasathi
val SoilBrown80  = Color(0xFFD4A76A)
val SoilBrown40  = Color(0xFF8B5E3C)
val LeafGreen80  = Color(0xFFA5D6A7)
val LeafGreen40  = Color(0xFF388E3C)
val WarmAmber80  = Color(0xFFFFCC80)
val WarmAmber40  = Color(0xFFFF8C00)
val Cream        = Color(0xFFFFF8F0)
val DarkBrown    = Color(0xFF3E2723)
