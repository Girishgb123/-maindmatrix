package com.example.vijay.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.vijay.viewmodel.GramaVasathiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmStayDetailScreen(
    farmStayId: Long,
    viewModel: GramaVasathiViewModel,
    navController: NavController
) {
    val farmStays by viewModel.allFarmStays.collectAsState()
    val farmStay = farmStays.find { it.id == farmStayId }
    val reviews by viewModel.getReviews(farmStayId).collectAsState(initial = emptyList())

    var guestName by remember { mutableStateOf("") }
    var rating by remember { mutableIntStateOf(5) }
    var comment by remember { mutableStateOf("") }

    if (farmStay == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val activities = farmStay.activities.split(",").map { it.trim() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(farmStay.name, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(farmStay.name,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold)
                    Text("Hosted by ${farmStay.hostName}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary)
                    Text("${farmStay.village}, ${farmStay.district}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SuggestionChip(onClick = {}, label = {
                            Text("₹${farmStay.pricePerNight}/night")
                        })
                        SuggestionChip(onClick = {}, label = {
                            Text("Max ${farmStay.maxGuests} guests")
                        })
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                farmStay.hostReadinessScore >= 80 -> Color(0xFF4CAF50)
                                farmStay.hostReadinessScore >= 50 -> Color(0xFFFF9800)
                                else -> Color(0xFFF44336)
                            }
                        ) {
                            Text(
                                "✓ ${farmStay.hostReadinessScore}% Ready",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Description
            Text("About this Stay", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold)
            Text(farmStay.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            // Activities — Farm Experience list
            Text("Farm Experiences 🌾", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold)
            Card(shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    activities.forEach { activity ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🌱", modifier = Modifier.padding(end = 8.dp))
                            Text(activity, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            // Book Now button
            if (farmStay.isAvailable) {
                Button(
                    onClick = { navController.navigate("book_stay/${farmStay.id}") },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("📅 Reserve a Room", style = MaterialTheme.typography.titleMedium)
                }
            } else {
                OutlinedButton(
                    onClick = {},
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    shape = RoundedCornerShape(12.dp),
                    enabled = false
                ) {
                    Text("Currently Unavailable")
                }
            }

            Divider()

            // Review Corner
            Text("Guest Reviews ⭐", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold)

            // Add review form
            Card(shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Leave a Review", style = MaterialTheme.typography.titleSmall)

                    OutlinedTextField(
                        value = guestName,
                        onValueChange = { guestName = it },
                        label = { Text("Your Name") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )

                    // Star Rating
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Rating: ", style = MaterialTheme.typography.bodyMedium)
                        repeat(5) { i ->
                            IconButton(onClick = { rating = i + 1 },
                                modifier = Modifier.size(36.dp)) {
                                Icon(
                                    if (i < rating) Icons.Default.Star else Icons.Outlined.Star,
                                    null,
                                    tint = if (i < rating) Color(0xFFFFD700) else Color.Gray,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = comment,
                        onValueChange = { if (it.length <= 200) comment = it },
                        label = { Text("Your experience...") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        minLines = 2
                    )

                    Button(
                        onClick = {
                            if (guestName.isNotBlank() && comment.isNotBlank()) {
                                viewModel.addReview(farmStay.id, guestName, rating, comment)
                                guestName = ""
                                comment = ""
                                rating = 5
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = guestName.isNotBlank() && comment.isNotBlank(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Submit Review")
                    }
                }
            }

            // Reviews list
            if (reviews.isEmpty()) {
                Text("No reviews yet. Be the first to review!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline)
            } else {
                reviews.forEach { review ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(review.guestName,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f))
                                repeat(review.rating) {
                                    Icon(Icons.Default.Star, null,
                                        tint = Color(0xFFFFD700),
                                        modifier = Modifier.size(14.dp))
                                }
                            }
                            Text("\"${review.comment}\"",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
