package com.example.vijay.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Represents a rural home-stay listing in the catalog.
 */
@Entity(tableName = "farmstays")
data class FarmStayEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,                      // e.g. "Gowda's Millet Farm"
    val hostName: String,                  // e.g. "Ramappa Gowda"
    val village: String,                   // Village name
    val district: String,                  // District
    val description: String,
    val activities: String,                // Comma-separated: "Cow Milking,Field Plowing,Local Cooking"
    val pricePerNight: Int,                // in INR
    val maxGuests: Int,
    val hostReadinessScore: Int = 0,       // 0–100 calculated from checklist
    val isAvailable: Boolean = true,
    val imageUrl: String = "",
    val rating: Float = 0f,
    val reviewCount: Int = 0
)

/**
 * Tracks the host training checklist progress.
 * Each item in the "Guest Readiness" checklist is stored here.
 */
@Entity(tableName = "checklist_items")
data class ChecklistItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmStayId: Long,
    val itemName: String,       // e.g. "Clean bed sheets provided"
    val category: String,       // e.g. "Hygiene", "Safety", "Comfort"
    val isCompleted: Boolean = false,
    val pointsValue: Int = 10   // Each item worth 10 points toward readiness score
)

/**
 * Represents a simulated guest booking / room reservation.
 */
@Entity(tableName = "bookings")
data class BookingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmStayId: Long,
    val farmStayName: String,
    val guestName: String,
    val guestPhone: String,
    val checkInDate: Long,      // epoch millis
    val checkOutDate: Long,     // epoch millis
    val numberOfGuests: Int,
    val totalPrice: Int,
    val status: String = "Confirmed",  // "Confirmed", "Cancelled", "Completed"
    val bookedAt: Long = System.currentTimeMillis()
)

/**
 * Guest reviews for a farm stay.
 */
@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val farmStayId: Long,
    val guestName: String,
    val rating: Int,            // 1–5
    val comment: String,
    val timestamp: Long = System.currentTimeMillis()
)
