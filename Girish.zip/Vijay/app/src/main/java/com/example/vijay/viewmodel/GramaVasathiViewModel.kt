package com.example.vijay.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.vijay.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GramaVasathiViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = GramaVasathiDatabase.getDatabase(application).dao()

    // ── Streams ───────────────────────────────────────────────────────────────
    val allFarmStays: StateFlow<List<FarmStayEntity>> = dao.getAllFarmStays()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val allBookings: StateFlow<List<BookingEntity>> = dao.getAllBookings()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // ── FarmStay Operations ───────────────────────────────────────────────────
    fun addFarmStay(
        name: String, hostName: String, village: String, district: String,
        description: String, activities: String, pricePerNight: Int, maxGuests: Int
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val id = dao.insertFarmStay(
                FarmStayEntity(
                    name = name, hostName = hostName, village = village,
                    district = district, description = description,
                    activities = activities, pricePerNight = pricePerNight,
                    maxGuests = maxGuests
                )
            )
            // Seed default checklist for new farm stay
            val defaultItems = listOf(
                ChecklistItemEntity(farmStayId = id, itemName = "Clean bed sheets provided", category = "Hygiene"),
                ChecklistItemEntity(farmStayId = id, itemName = "Western-style toilet available", category = "Hygiene"),
                ChecklistItemEntity(farmStayId = id, itemName = "Safe drinking water (filter/boiled)", category = "Hygiene"),
                ChecklistItemEntity(farmStayId = id, itemName = "Regular pest control done", category = "Hygiene"),
                ChecklistItemEntity(farmStayId = id, itemName = "Soap and towels provided", category = "Hygiene"),
                ChecklistItemEntity(farmStayId = id, itemName = "First aid kit present", category = "Safety"),
                ChecklistItemEntity(farmStayId = id, itemName = "Emergency contact numbers posted", category = "Safety"),
                ChecklistItemEntity(farmStayId = id, itemName = "Proper locks on guest room door", category = "Safety"),
                ChecklistItemEntity(farmStayId = id, itemName = "Mosquito nets or repellent provided", category = "Comfort"),
                ChecklistItemEntity(farmStayId = id, itemName = "Menu / food preference discussed with guest", category = "Comfort")
            )
            defaultItems.forEach { dao.insertChecklistItem(it) }
        }
    }

    // ── Checklist Operations ──────────────────────────────────────────────────
    fun getChecklist(farmStayId: Long): Flow<List<ChecklistItemEntity>> =
        dao.getChecklistForFarmStay(farmStayId)

    fun toggleChecklistItem(item: ChecklistItemEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.updateChecklistItem(item.copy(isCompleted = !item.isCompleted))
            recalculateReadinessScore(item.farmStayId)
        }
    }

    private suspend fun recalculateReadinessScore(farmStayId: Long) {
        val all = dao.getAllChecklistItems(farmStayId)
        val completed = dao.getCompletedChecklistItems(farmStayId)
        val score = if (all.isEmpty()) 0
        else ((completed.sumOf { it.pointsValue }.toFloat() / all.sumOf { it.pointsValue }) * 100).toInt()
        val farmStay = dao.getFarmStayById(farmStayId) ?: return
        dao.updateFarmStay(farmStay.copy(hostReadinessScore = score))
    }

    // ── Booking Operations ────────────────────────────────────────────────────
    fun makeBooking(
        farmStayId: Long, farmStayName: String, guestName: String,
        guestPhone: String, checkIn: Long, checkOut: Long,
        guests: Int, pricePerNight: Int
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val nights = ((checkOut - checkIn) / (1000 * 60 * 60 * 24)).toInt().coerceAtLeast(1)
            val total = nights * pricePerNight * guests
            dao.insertBooking(
                BookingEntity(
                    farmStayId = farmStayId,
                    farmStayName = farmStayName,
                    guestName = guestName,
                    guestPhone = guestPhone,
                    checkInDate = checkIn,
                    checkOutDate = checkOut,
                    numberOfGuests = guests,
                    totalPrice = total
                )
            )
        }
    }

    fun getBookingsForFarmStay(farmStayId: Long): Flow<List<BookingEntity>> =
        dao.getBookingsForFarmStay(farmStayId)

    // ── Reviews ───────────────────────────────────────────────────────────────
    fun getReviews(farmStayId: Long): Flow<List<ReviewEntity>> =
        dao.getReviewsForFarmStay(farmStayId)

    fun addReview(farmStayId: Long, guestName: String, rating: Int, comment: String) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertReview(ReviewEntity(
                farmStayId = farmStayId,
                guestName = guestName,
                rating = rating,
                comment = comment
            ))
            // Update aggregate rating on FarmStay
            val avg = dao.getAverageRating(farmStayId) ?: 0f
            val count = dao.getReviewCount(farmStayId)
            val farmStay = dao.getFarmStayById(farmStayId) ?: return@launch
            dao.updateFarmStay(farmStay.copy(rating = avg, reviewCount = count))
        }
    }
}
