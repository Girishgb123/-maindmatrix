package com.example.vijay.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.vijay.viewmodel.GramaVasathiViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookStayScreen(
    farmStayId: Long,
    viewModel: GramaVasathiViewModel,
    navController: NavController
) {
    val farmStays by viewModel.allFarmStays.collectAsState()
    val farmStay = farmStays.find { it.id == farmStayId }

    var guestName by remember { mutableStateOf("") }
    var guestPhone by remember { mutableStateOf("") }
    var numberOfGuests by remember { mutableStateOf("1") }
    var checkInDay by remember { mutableIntStateOf(-1) }
    var checkOutDay by remember { mutableIntStateOf(-1) }
    var showConfirmation by remember { mutableStateOf(false) }

    // Simple calendar — current month
    val calendar = remember { Calendar.getInstance() }
    var displayMonth by remember { mutableIntStateOf(calendar.get(Calendar.MONTH)) }
    var displayYear by remember { mutableIntStateOf(calendar.get(Calendar.YEAR)) }

    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    val monthNames = listOf("Jan","Feb","Mar","Apr","May","Jun",
        "Jul","Aug","Sep","Oct","Nov","Dec")

    fun dayToEpoch(day: Int): Long {
        val cal = Calendar.getInstance()
        cal.set(displayYear, displayMonth, day, 12, 0, 0)
        return cal.timeInMillis
    }

    fun daysInMonth(): Int {
        val cal = Calendar.getInstance()
        cal.set(displayYear, displayMonth, 1)
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    fun firstDayOffset(): Int {
        val cal = Calendar.getInstance()
        cal.set(displayYear, displayMonth, 1)
        return (cal.get(Calendar.DAY_OF_WEEK) - 1) // 0=Sun
    }

    if (farmStay == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    if (showConfirmation) {
        // Booking confirmed dialog
        AlertDialog(
            onDismissRequest = { navController.navigate("bookings") },
            title = { Text("🎉 Booking Confirmed!") },
            text = {
                Column {
                    Text("Your stay at ${farmStay.name} has been reserved.")
                    Spacer(modifier = Modifier.height(8.dp))
                    if (checkInDay > 0 && checkOutDay > 0) {
                        Text("Check-in:  ${sdf.format(Date(dayToEpoch(checkInDay)))}")
                        Text("Check-out: ${sdf.format(Date(dayToEpoch(checkOutDay)))}")
                        val nights = (checkOutDay - checkInDay).coerceAtLeast(1)
                        val guests = numberOfGuests.toIntOrNull() ?: 1
                        Text("Total: ₹${nights * farmStay.pricePerNight * guests}")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Matti-Vasane experience awaits! 🌱",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    navController.navigate("bookings") {
                        popUpTo("discover") { inclusive = false }
                    }
                }) { Text("View Bookings") }
            },
            dismissButton = {
                TextButton(onClick = { navController.popBackStack() }) { Text("Back") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reserve a Room", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Stay summary
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)
                )
            ) {
                Row(modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("🌾", style = MaterialTheme.typography.headlineMedium,
                        modifier = Modifier.padding(end = 12.dp))
                    Column {
                        Text(farmStay.name, fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium)
                        Text("${farmStay.village} · ₹${farmStay.pricePerNight}/night",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            // ── Simulated Calendar ────────────────────────────────────────────
            Text("Select Dates", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold)

            Card(shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Month navigation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            if (displayMonth == 0) { displayMonth = 11; displayYear-- }
                            else displayMonth--
                            checkInDay = -1; checkOutDay = -1
                        }) {
                            Icon(Icons.Default.ArrowBack, "Prev")
                        }
                        Text("${monthNames[displayMonth]} $displayYear",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = {
                            if (displayMonth == 11) { displayMonth = 0; displayYear++ }
                            else displayMonth++
                            checkInDay = -1; checkOutDay = -1
                        }) {
                            Icon(Icons.Default.ArrowForward, "Next")
                        }
                    }

                    // Day-of-week headers
                    Row(modifier = Modifier.fillMaxWidth()) {
                        listOf("Su","Mo","Tu","We","Th","Fr","Sa").forEach { d ->
                            Text(d,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))

                    // Calendar grid
                    val days = daysInMonth()
                    val offset = firstDayOffset()
                    val totalCells = days + offset
                    val rows = (totalCells + 6) / 7

                    for (row in 0 until rows) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            for (col in 0 until 7) {
                                val cellIndex = row * 7 + col
                                val day = cellIndex - offset + 1
                                val isValid = day in 1..days
                                val isCheckIn = day == checkInDay
                                val isCheckOut = day == checkOutDay
                                val isInRange = checkInDay > 0 && checkOutDay > 0
                                    && day > checkInDay && day < checkOutDay

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .padding(2.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                !isValid -> Color.Transparent
                                                isCheckIn || isCheckOut -> MaterialTheme.colorScheme.primary
                                                isInRange -> MaterialTheme.colorScheme.primaryContainer
                                                else -> Color.Transparent
                                            }
                                        )
                                        .then(
                                            if (isValid) Modifier.clickable {
                                                when {
                                                    checkInDay == -1 -> checkInDay = day
                                                    checkOutDay == -1 && day > checkInDay -> checkOutDay = day
                                                    else -> { checkInDay = day; checkOutDay = -1 }
                                                }
                                            } else Modifier
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isValid) {
                                        Text(
                                            "$day",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = if (isCheckIn || isCheckOut) FontWeight.Bold else FontWeight.Normal,
                                            color = when {
                                                isCheckIn || isCheckOut -> MaterialTheme.colorScheme.onPrimary
                                                isInRange -> MaterialTheme.colorScheme.onPrimaryContainer
                                                else -> MaterialTheme.colorScheme.onSurface
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Selected range display
                    if (checkInDay > 0 || checkOutDay > 0) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Check-in", style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    if (checkInDay > 0) "${monthNames[displayMonth]} $checkInDay" else "—",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Check-out", style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    if (checkOutDay > 0) "${monthNames[displayMonth]} $checkOutDay" else "—",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            if (checkInDay > 0 && checkOutDay > 0) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Nights", style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        "${checkOutDay - checkInDay}",
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Guest Details
            Text("Guest Details", style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold)

            OutlinedTextField(
                value = guestName,
                onValueChange = { guestName = it },
                label = { Text("Guest Name") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )
            OutlinedTextField(
                value = guestPhone,
                onValueChange = { guestPhone = it },
                label = { Text("Phone Number") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
            OutlinedTextField(
                value = numberOfGuests,
                onValueChange = { v ->
                    val n = v.toIntOrNull()
                    if (n != null && n in 1..farmStay.maxGuests) numberOfGuests = v
                    else if (v.isEmpty()) numberOfGuests = v
                },
                label = { Text("Number of Guests (max ${farmStay.maxGuests})") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )

            // Price summary
            if (checkInDay > 0 && checkOutDay > 0) {
                val nights = (checkOutDay - checkInDay).coerceAtLeast(1)
                val guests = numberOfGuests.toIntOrNull() ?: 1
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Price Summary", fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("₹${farmStay.pricePerNight} × $nights nights × $guests guests")
                            Text("₹${farmStay.pricePerNight * nights * guests}",
                                fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Confirm button
            val isFormValid = guestName.isNotBlank() && guestPhone.isNotBlank()
                && checkInDay > 0 && checkOutDay > 0 && checkInDay < checkOutDay

            Button(
                onClick = {
                    val guests = numberOfGuests.toIntOrNull() ?: 1
                    viewModel.makeBooking(
                        farmStayId = farmStay.id,
                        farmStayName = farmStay.name,
                        guestName = guestName,
                        guestPhone = guestPhone,
                        checkIn = dayToEpoch(checkInDay),
                        checkOut = dayToEpoch(checkOutDay),
                        guests = guests,
                        pricePerNight = farmStay.pricePerNight
                    )
                    showConfirmation = true
                },
                enabled = isFormValid,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Confirm Booking 🌾", style = MaterialTheme.typography.titleMedium)
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
