package com.example.vijay.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.vijay.viewmodel.GramaVasathiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFarmStayScreen(viewModel: GramaVasathiViewModel, navController: NavController) {
    var name by remember { mutableStateOf("") }
    var hostName by remember { mutableStateOf("") }
    var village by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var maxGuests by remember { mutableStateOf("4") }

    // Activity selection
    val allActivities = listOf(
        "Cow Milking", "Field Plowing", "Local Cooking", "Bird Watching",
        "Coffee Picking", "Fishing", "Nature Walk", "Yoga at Sunrise",
        "Paddy Planting", "Bullock Cart Ride", "Cooking Class", "Forest Trek",
        "Village Market Visit", "Pottery Making", "Organic Farming Tour"
    )
    val selectedActivities = remember { mutableStateListOf<String>() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("List Your Farm Stay", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("Tell us about your place",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            OutlinedTextField(value = name, onValueChange = { name = it },
                label = { Text("Farm Stay Name") },
                placeholder = { Text("e.g. Gowda's Millet Farm") },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true)

            OutlinedTextField(value = hostName, onValueChange = { hostName = it },
                label = { Text("Your Name (Host)") },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = village, onValueChange = { village = it },
                    label = { Text("Village") },
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), singleLine = true)
                OutlinedTextField(value = district, onValueChange = { district = it },
                    label = { Text("District") },
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), singleLine = true)
            }

            OutlinedTextField(value = description, onValueChange = { description = it },
                label = { Text("Description") },
                placeholder = { Text("Describe your farm, the surroundings, what makes it special...") },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), minLines = 3)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = price, onValueChange = { price = it },
                    label = { Text("Price/Night (₹)") },
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(value = maxGuests, onValueChange = { maxGuests = it },
                    label = { Text("Max Guests") },
                    modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }

            // Activity selection
            Text("Farm Experiences Offered",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold)
            Text("Select all activities your guests can enjoy",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)

            // Wrap in a FlowRow-like grid using chunked rows
            allActivities.chunked(2).forEach { rowItems ->
                Row(modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { activity ->
                        FilterChip(
                            selected = selectedActivities.contains(activity),
                            onClick = {
                                if (selectedActivities.contains(activity))
                                    selectedActivities.remove(activity)
                                else
                                    selectedActivities.add(activity)
                            },
                            label = { Text(activity, style = MaterialTheme.typography.labelMedium) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (rowItems.size == 1) Spacer(modifier = Modifier.weight(1f))
                }
            }

            if (selectedActivities.isNotEmpty()) {
                Text("Selected: ${selectedActivities.joinToString(", ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary)
            }

            Spacer(modifier = Modifier.height(8.dp))

            val isValid = name.isNotBlank() && hostName.isNotBlank() &&
                village.isNotBlank() && district.isNotBlank() &&
                price.toIntOrNull() != null && selectedActivities.isNotEmpty()

            Button(
                onClick = {
                    viewModel.addFarmStay(
                        name = name,
                        hostName = hostName,
                        village = village,
                        district = district,
                        description = description,
                        activities = selectedActivities.joinToString(","),
                        pricePerNight = price.toIntOrNull() ?: 1000,
                        maxGuests = maxGuests.toIntOrNull() ?: 4
                    )
                    navController.popBackStack()
                },
                enabled = isValid,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("List My Farm Stay 🌾", style = MaterialTheme.typography.titleMedium)
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
